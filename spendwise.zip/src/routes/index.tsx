import { createFileRoute } from "@tanstack/react-router";
import { Dashboard } from "@/components/Dashboard";

const title = "SpendWise — Smart Budget Tracker for Students";
const description =
  "Track expenses, watch your monthly budget, and get plain-English insights into where your money actually goes.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});
