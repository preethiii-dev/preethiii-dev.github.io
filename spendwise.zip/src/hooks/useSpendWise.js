import { useCallback, useEffect, useMemo, useState } from "react";
import {
  loadBudget,
  loadExpenses,
  loadTheme,
  saveBudget,
  saveExpenses,
  saveTheme,
} from "@/lib/storage";
import { buildDemoExpenses, createExpense } from "@/lib/finance";

const DEFAULT_BUDGET = 5000;

export function useSpendWise() {
  const [expenses, setExpenses] = useState([]);
  const [budget, setBudget] = useState(DEFAULT_BUDGET);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setExpenses(loadExpenses());
    setBudget(loadBudget(DEFAULT_BUDGET));
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) saveExpenses(expenses);
  }, [expenses, hydrated]);

  useEffect(() => {
    if (hydrated) saveBudget(budget);
  }, [budget, hydrated]);

  const addExpense = useCallback((input) => {
    setExpenses((prev) => [createExpense(input), ...prev]);
  }, []);

  const deleteExpense = useCallback((id) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
  }, []);

  const loadDemoData = useCallback(() => {
    setExpenses(buildDemoExpenses());
  }, []);

  const clearAll = useCallback(() => setExpenses([]), []);

  const updateBudget = useCallback((value) => {
    const amount = Number(value);
    if (Number.isFinite(amount) && amount > 0) setBudget(amount);
  }, []);

  return useMemo(
    () => ({
      expenses,
      budget,
      hydrated,
      addExpense,
      deleteExpense,
      loadDemoData,
      clearAll,
      updateBudget,
    }),
    [expenses, budget, hydrated, addExpense, deleteExpense, loadDemoData, clearAll, updateBudget],
  );
}

export function useTheme() {
  const [theme, setTheme] = useState("light");

  useEffect(() => {
    const stored = loadTheme();
    const prefersDark =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-color-scheme: dark)").matches;
    setTheme(stored || (prefersDark ? "dark" : "light"));
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", theme === "dark");
    root.style.colorScheme = theme;
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => {
      const next = prev === "dark" ? "light" : "dark";
      saveTheme(next);
      return next;
    });
  }, []);

  return { theme, toggleTheme };
}
