import { useEffect, useState } from "react";
import { BUDGET_STATE_LABEL, formatMoney } from "@/lib/finance";

const RING_COLOR = {
  healthy: "#1e7a5b",
  approaching: "#f4a63c",
  exceeded: "#dc2626",
};

const VALUE_COLOR = {
  healthy: "text-brand",
  approaching: "text-accent",
  exceeded: "text-red-600 dark:text-red-400",
};

export function BudgetProgress({ stats, onEditBudget }) {
  const { spent, budget, remaining, percent, state } = stats;
  const capped = Math.max(0, Math.min(percent, 100));
  const [sweep, setSweep] = useState(0);

  useEffect(() => {
    const id = requestAnimationFrame(() => setSweep(capped));
    return () => cancelAnimationFrame(id);
  }, [capped]);

  return (
    <section className="col-span-12 rounded-[22px] bg-white p-6 ring-1 ring-black/5 lg:col-span-4 dark:bg-stone-900 dark:ring-white/10">
      <div className="flex items-center justify-between">
        <h2 className="font-display text-sm font-semibold">Budget Health</h2>
        <button
          type="button"
          onClick={onEditBudget}
          className="text-xs font-medium text-brand hover:underline"
        >
          Edit budget
        </button>
      </div>

      <div className="mt-4 grid place-items-center">
        <div className="relative">
          <div
            className="size-44 rounded-full transition-[background] duration-700 ease-out"
            style={{
              background: `conic-gradient(${RING_COLOR[state]} 0deg ${sweep * 3.6}deg, var(--ring-track) ${sweep * 3.6}deg 360deg)`,
            }}
          />
          <div className="absolute inset-3 grid place-items-center rounded-full bg-white dark:bg-stone-900">
            <div className="text-center">
              <p className="font-display text-4xl font-semibold leading-none tracking-tight tabular-nums">
                {Math.round(percent)}%
              </p>
              <p className="mt-1 text-xs text-stone-500 dark:text-stone-400">
                of budget used
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-5 space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-stone-500 dark:text-stone-400">Spent</span>
          <span className="font-medium tabular-nums">{formatMoney(spent)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-stone-500 dark:text-stone-400">Monthly budget</span>
          <span className="font-medium tabular-nums">{formatMoney(budget)}</span>
        </div>
        <div className="flex justify-between border-t border-stone-100 pt-2 dark:border-stone-800">
          <span className="text-stone-500 dark:text-stone-400">
            {remaining < 0 ? "Over budget by" : "Remaining"}
          </span>
          <span className={`font-semibold tabular-nums ${VALUE_COLOR[state]}`}>
            {formatMoney(Math.abs(remaining))}
          </span>
        </div>
        <p className="pt-1 text-xs text-stone-400">{BUDGET_STATE_LABEL[state]}</p>
      </div>
    </section>
  );
}
