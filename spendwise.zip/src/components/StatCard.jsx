export function StatCard({ label, value, hint }) {
  return (
    <div className="rounded-[22px] bg-white p-5 ring-1 ring-black/5 transition-transform hover:-translate-y-0.5 dark:bg-stone-900 dark:ring-white/10">
      <p className="text-xs font-medium text-stone-400">{label}</p>
      <p className="font-display mt-2 text-2xl font-semibold tracking-tight tabular-nums">
        {value}
      </p>
      <p className="mt-1 truncate text-xs text-stone-400">{hint}</p>
    </div>
  );
}
