import { Plus, Wand2 } from "lucide-react";

export function EmptyState({ onAdd, onLoadDemo }) {
  return (
    <section className="col-span-12 overflow-hidden rounded-[22px] bg-white p-10 text-center ring-1 ring-black/5 dark:bg-stone-900 dark:ring-white/10">
      <div className="mx-auto max-w-md">
        <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-brand/10 text-brand">
          <Wand2 className="size-6" />
        </div>
        <h2 className="font-display mt-5 text-2xl font-semibold tracking-tight">
          Your spending story starts here.
        </h2>
        <p className="mt-2 text-sm text-stone-500 dark:text-stone-400">
          Add your first expense and SpendWise will start tracking your budget,
          spotting patterns and telling you where your money is really going.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            type="button"
            onClick={onAdd}
            className="inline-flex h-10 items-center gap-2 rounded-lg bg-brand px-5 text-sm font-semibold text-white shadow-sm transition-transform hover:-translate-y-0.5"
          >
            <Plus className="size-4" /> Add your first expense
          </button>
          <button
            type="button"
            onClick={onLoadDemo}
            className="inline-flex h-10 items-center rounded-lg px-5 text-sm font-medium text-stone-600 ring-1 ring-stone-200 transition-colors hover:bg-stone-50 dark:text-stone-300 dark:ring-stone-700 dark:hover:bg-stone-800"
          >
            Load demo data
          </button>
        </div>
      </div>
    </section>
  );
}
