import { Moon, Sun } from "lucide-react";

export function ThemeToggle({ theme, onToggle }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
      className="grid size-9 place-items-center rounded-lg text-stone-500 ring-1 ring-stone-200 transition-all hover:-translate-y-0.5 hover:text-stone-900 dark:text-stone-400 dark:ring-stone-700 dark:hover:text-stone-100"
    >
      {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
    </button>
  );
}
