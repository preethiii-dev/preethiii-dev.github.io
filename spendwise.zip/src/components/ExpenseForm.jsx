import { useEffect, useState } from "react";
import { Modal } from "@/components/Modal";
import { CATEGORIES, toISODate } from "@/lib/finance";

const fieldClass =
  "mt-1.5 h-10 w-full rounded-lg bg-transparent px-3 text-sm outline-none ring-1 ring-stone-200 transition-colors focus:ring-brand dark:ring-stone-700";

const emptyForm = () => ({
  name: "",
  amount: "",
  category: "Food",
  date: toISODate(new Date()),
});

export function ExpenseForm({ open, onClose, onSubmit }) {
  const [values, setValues] = useState(emptyForm);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (open) {
      setValues(emptyForm());
      setErrors({});
    }
  }, [open]);

  const set = (patch) => setValues((prev) => ({ ...prev, ...patch }));

  const validate = () => {
    const next = {};
    if (!values.name.trim()) next.name = "Give this expense a name.";
    else if (values.name.trim().length > 60) next.name = "Keep the name under 60 characters.";

    const amount = Number(values.amount);
    if (!values.amount) next.amount = "Enter an amount.";
    else if (!Number.isFinite(amount) || amount <= 0) next.amount = "Amount must be greater than 0.";
    else if (amount > 1000000) next.amount = "That amount looks too large.";

    if (!values.date) next.date = "Pick a date.";
    else if (new Date(`${values.date}T00:00:00`) > new Date()) next.date = "Date can't be in the future.";

    if (!CATEGORIES.includes(values.category)) next.category = "Pick a category.";

    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!validate()) return;
    onSubmit({
      name: values.name,
      amount: Number(values.amount),
      category: values.category,
      date: values.date,
    });
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Add an expense"
      description="It's saved on this device and updates your dashboard instantly."
    >
      <form onSubmit={handleSubmit} noValidate className="space-y-4">
        <div>
          <label htmlFor="expense-name" className="text-xs font-medium text-stone-500 dark:text-stone-400">
            Expense name
          </label>
          <input
            id="expense-name"
            value={values.name}
            onChange={(e) => set({ name: e.target.value })}
            placeholder="Campus canteen lunch"
            className={fieldClass}
            autoFocus
          />
          {errors.name ? <p className="mt-1 text-xs text-red-600 dark:text-red-400">{errors.name}</p> : null}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label htmlFor="expense-amount" className="text-xs font-medium text-stone-500 dark:text-stone-400">
              Amount (₹)
            </label>
            <input
              id="expense-amount"
              type="number"
              inputMode="decimal"
              min="1"
              step="1"
              value={values.amount}
              onChange={(e) => set({ amount: e.target.value })}
              placeholder="180"
              className={fieldClass}
            />
            {errors.amount ? <p className="mt-1 text-xs text-red-600 dark:text-red-400">{errors.amount}</p> : null}
          </div>
          <div>
            <label htmlFor="expense-category" className="text-xs font-medium text-stone-500 dark:text-stone-400">
              Category
            </label>
            <select
              id="expense-category"
              value={values.category}
              onChange={(e) => set({ category: e.target.value })}
              className={fieldClass}
            >
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="expense-date" className="text-xs font-medium text-stone-500 dark:text-stone-400">
            Date
          </label>
          <input
            id="expense-date"
            type="date"
            value={values.date}
            max={toISODate(new Date())}
            onChange={(e) => set({ date: e.target.value })}
            className={fieldClass}
          />
          {errors.date ? <p className="mt-1 text-xs text-red-600 dark:text-red-400">{errors.date}</p> : null}
        </div>

        <div className="flex justify-end gap-2 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="h-10 rounded-lg px-4 text-sm font-medium text-stone-500 transition-colors hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="h-10 rounded-lg bg-brand px-5 text-sm font-semibold text-white shadow-sm transition-transform hover:-translate-y-0.5"
          >
            Add expense
          </button>
        </div>
      </form>
    </Modal>
  );
}
