import { useMemo, useState } from "react";
import { ExpenseCard } from "@/components/ExpenseCard";
import { SearchFilters } from "@/components/SearchFilters";
import { inRange, parseDate } from "@/lib/finance";

const EMPTY_FILTERS = {
  query: "",
  category: "all",
  from: "",
  to: "",
  sort: "newest",
};

export function ExpenseList({ expenses, onDelete }) {
  const [filters, setFilters] = useState(EMPTY_FILTERS);

  const visible = useMemo(() => {
    const query = filters.query.trim().toLowerCase();
    const from = filters.from ? parseDate(filters.from) : null;
    const to = filters.to ? parseDate(filters.to) : null;

    const result = expenses.filter((e) => {
      if (query && !e.name.toLowerCase().includes(query)) return false;
      if (filters.category !== "all" && e.category !== filters.category) return false;
      if ((from || to) && !inRange(e.date, from, to)) return false;
      return true;
    });

    const sorters = {
      newest: (a, b) => b.date.localeCompare(a.date),
      oldest: (a, b) => a.date.localeCompare(b.date),
      high: (a, b) => b.amount - a.amount,
      low: (a, b) => a.amount - b.amount,
    };

    return result.sort(sorters[filters.sort]);
  }, [expenses, filters]);

  return (
    <section
      id="expenses"
      className="col-span-12 rounded-[22px] bg-white p-6 ring-1 ring-black/5 dark:bg-stone-900 dark:ring-white/10"
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-sm font-semibold">
          All expenses
          <span className="ml-2 font-sans text-xs font-normal text-stone-400">
            {visible.length} of {expenses.length}
          </span>
        </h2>
        <SearchFilters
          filters={filters}
          onChange={setFilters}
          onReset={() => setFilters(EMPTY_FILTERS)}
        />
      </div>

      {visible.length === 0 ? (
        <p className="py-10 text-center text-sm text-stone-400">
          No expenses match these filters.
        </p>
      ) : (
        <div className="mt-2 divide-y divide-stone-100 dark:divide-stone-800">
          {visible.map((expense) => (
            <ExpenseCard key={expense.id} expense={expense} onDelete={onDelete} />
          ))}
        </div>
      )}
    </section>
  );
}
