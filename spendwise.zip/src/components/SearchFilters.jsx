import { Search } from "lucide-react";
import { CATEGORIES } from "@/lib/finance";

const inputClass =
  "h-9 rounded-lg bg-transparent px-3 text-sm text-stone-700 outline-none ring-1 ring-stone-200 transition-colors focus:ring-brand dark:text-stone-200 dark:ring-stone-700";

export function SearchFilters({ filters, onChange, onReset }) {
  const set = (patch) => onChange({ ...filters, ...patch });

  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="flex h-9 min-w-[190px] flex-1 items-center gap-2 rounded-lg px-2.5 ring-1 ring-stone-200 focus-within:ring-brand dark:ring-stone-700">
        <Search className="size-3.5 text-stone-400" />
        <input
          value={filters.query}
          onChange={(e) => set({ query: e.target.value })}
          placeholder="Search expenses…"
          aria-label="Search expenses"
          className="w-full bg-transparent text-sm outline-none placeholder:text-stone-400"
        />
      </div>

      <select
        value={filters.category}
        onChange={(e) => set({ category: e.target.value })}
        aria-label="Filter by category"
        className={inputClass}
      >
        <option value="all">All categories</option>
        {CATEGORIES.map((c) => (
          <option key={c} value={c}>
            {c}
          </option>
        ))}
      </select>

      <input
        type="date"
        value={filters.from}
        onChange={(e) => set({ from: e.target.value })}
        aria-label="From date"
        className={inputClass}
      />
      <input
        type="date"
        value={filters.to}
        onChange={(e) => set({ to: e.target.value })}
        aria-label="To date"
        className={inputClass}
      />

      <select
        value={filters.sort}
        onChange={(e) => set({ sort: e.target.value })}
        aria-label="Sort expenses"
        className={inputClass}
      >
        <option value="newest">Newest first</option>
        <option value="oldest">Oldest first</option>
        <option value="high">Amount: high to low</option>
        <option value="low">Amount: low to high</option>
      </select>

      <button
        type="button"
        onClick={onReset}
        className="h-9 rounded-lg px-3 text-sm text-stone-500 transition-colors hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100"
      >
        Reset
      </button>
    </div>
  );
}
