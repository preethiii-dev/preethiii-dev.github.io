import { useEffect, useState } from "react";
import { Modal } from "@/components/Modal";
import { formatMoney } from "@/lib/finance";

export function BudgetDialog({ open, budget, spent, onClose, onSave }) {
  const [value, setValue] = useState(String(budget));
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setValue(String(budget));
      setError("");
    }
  }, [open, budget]);

  const handleSubmit = (event) => {
    event.preventDefault();
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) {
      setError("Enter a budget greater than 0.");
      return;
    }
    onSave(amount);
    onClose();
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Monthly budget"
      description={`You've spent ${formatMoney(spent)} so far this month.`}
    >
      <form onSubmit={handleSubmit} noValidate className="space-y-4">
        <div>
          <label htmlFor="budget-amount" className="text-xs font-medium text-stone-500 dark:text-stone-400">
            Budget for this month (₹)
          </label>
          <input
            id="budget-amount"
            type="number"
            min="1"
            step="100"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            className="mt-1.5 h-10 w-full rounded-lg bg-transparent px-3 text-sm outline-none ring-1 ring-stone-200 transition-colors focus:ring-brand dark:ring-stone-700"
            autoFocus
          />
          {error ? <p className="mt-1 text-xs text-red-600 dark:text-red-400">{error}</p> : null}
        </div>
        <div className="flex flex-wrap gap-2">
          {[3000, 5000, 8000, 12000].map((preset) => (
            <button
              key={preset}
              type="button"
              onClick={() => setValue(String(preset))}
              className="rounded-lg px-3 py-1.5 text-xs font-medium text-stone-600 ring-1 ring-stone-200 transition-colors hover:bg-brand/10 hover:text-brand dark:text-stone-300 dark:ring-stone-700"
            >
              {formatMoney(preset)}
            </button>
          ))}
        </div>
        <div className="flex justify-end gap-2 pt-1">
          <button
            type="button"
            onClick={onClose}
            className="h-10 rounded-lg px-4 text-sm font-medium text-stone-500 transition-colors hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="h-10 rounded-lg bg-brand px-5 text-sm font-semibold text-white shadow-sm transition-transform hover:-translate-y-0.5"
          >
            Save budget
          </button>
        </div>
      </form>
    </Modal>
  );
}
