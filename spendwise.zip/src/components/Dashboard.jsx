import { useMemo, useState } from "react";
import { Plus } from "lucide-react";
import { BudgetDialog } from "@/components/BudgetDialog";
import { BudgetProgress } from "@/components/BudgetProgress";
import { CategoryBreakdown } from "@/components/CategoryBreakdown";
import { EmptyState } from "@/components/EmptyState";
import { ExpenseForm } from "@/components/ExpenseForm";
import { ExpenseList } from "@/components/ExpenseList";
import { SmartInsights } from "@/components/SmartInsights";
import { SpendingChart } from "@/components/SpendingChart";
import { StatCard } from "@/components/StatCard";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useSpendWise, useTheme } from "@/hooks/useSpendWise";
import {
  BUDGET_STATE_LABEL,
  filterByRange,
  formatMoney,
  getStats,
  monthLabel,
} from "@/lib/finance";

const RANGES = [
  { id: "week", label: "This week" },
  { id: "month", label: "This month" },
  { id: "all", label: "All time" },
];

const STATE_PILL = {
  healthy: "bg-brand/10 text-brand",
  approaching: "bg-accent/15 text-accent",
  exceeded: "bg-red-100 text-red-700 dark:bg-red-950/50 dark:text-red-400",
};

const STATE_DOT = {
  healthy: "bg-brand",
  approaching: "bg-accent",
  exceeded: "bg-red-500",
};

export function Dashboard() {
  const {
    expenses,
    budget,
    addExpense,
    deleteExpense,
    loadDemoData,
    clearAll,
    updateBudget,
  } = useSpendWise();
  const { theme, toggleTheme } = useTheme();

  const [range, setRange] = useState("month");
  const [formOpen, setFormOpen] = useState(false);
  const [budgetOpen, setBudgetOpen] = useState(false);

  const stats = useMemo(() => getStats(expenses, budget), [expenses, budget]);
  const ranged = useMemo(() => filterByRange(expenses, range), [expenses, range]);
  const rangeLabel = RANGES.find((r) => r.id === range)?.label ?? "This month";
  const hasData = expenses.length > 0;

  return (
    <div className="min-h-screen bg-stone-100 text-stone-900 antialiased dark:bg-stone-950 dark:text-stone-100">
      <header className="sticky top-0 z-30 border-b border-stone-200 bg-stone-50/80 backdrop-blur dark:border-stone-800 dark:bg-stone-900/70">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8">
          <div className="flex items-center gap-2.5">
            <div className="font-display grid size-8 place-items-center rounded-lg bg-brand font-bold text-white">
              S
            </div>
            <span className="font-display text-[15px] font-semibold tracking-tight">
              SpendWise
            </span>
          </div>
          <nav className="hidden items-center gap-7 text-sm font-medium text-stone-500 md:flex dark:text-stone-400">
            <a href="#overview" className="text-stone-900 dark:text-stone-100">
              Overview
            </a>
            <a href="#expenses" className="transition-colors hover:text-stone-900 dark:hover:text-stone-100">
              Expenses
            </a>
            <a href="#analytics" className="transition-colors hover:text-stone-900 dark:hover:text-stone-100">
              Analytics
            </a>
          </nav>
          <div className="flex items-center gap-2">
            <ThemeToggle theme={theme} onToggle={toggleTheme} />
            <button
              type="button"
              onClick={() => setBudgetOpen(true)}
              className="hidden h-9 rounded-lg px-3 text-sm font-medium text-stone-600 ring-1 ring-stone-200 transition-colors hover:bg-white sm:block dark:text-stone-300 dark:ring-stone-700 dark:hover:bg-stone-800"
            >
              Budget
            </button>
          </div>
        </div>
      </header>

      <main id="overview" className="mx-auto max-w-7xl px-5 py-7 pb-28 sm:px-8">
        <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-stone-400">
              {monthLabel()}
            </p>
            <h1 className="font-display mt-1 text-2xl font-semibold tracking-tight sm:text-3xl">
              This month at a glance
            </h1>
          </div>
          <span
            className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium ${STATE_PILL[stats.state]}`}
          >
            <span className={`size-1.5 rounded-full ${STATE_DOT[stats.state]}`} />
            {BUDGET_STATE_LABEL[stats.state]}
          </span>
        </div>

        <div className="grid grid-cols-12 gap-4">
          {!hasData ? (
            <EmptyState onAdd={() => setFormOpen(true)} onLoadDemo={loadDemoData} />
          ) : (
            <>
              <BudgetProgress stats={stats} onEditBudget={() => setBudgetOpen(true)} />

              <div className="col-span-12 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:col-span-8">
                <StatCard
                  label="Spent this month"
                  value={formatMoney(stats.spent)}
                  hint={`of ${formatMoney(stats.budget)} budget`}
                />
                <StatCard
                  label="Remaining"
                  value={formatMoney(Math.abs(stats.remaining))}
                  hint={stats.remaining < 0 ? "over budget" : `${100 - Math.round(stats.percent)}% left`}
                />
                <StatCard
                  label="Transactions"
                  value={stats.count}
                  hint="this cycle"
                />
                <StatCard
                  label="Highest expense"
                  value={stats.highest ? formatMoney(stats.highest.amount) : "₹0"}
                  hint={stats.highest ? stats.highest.name : "no expenses yet"}
                />
                <div className="col-span-2 rounded-[22px] bg-white p-5 ring-1 ring-black/5 sm:col-span-4 dark:bg-stone-900 dark:ring-white/10">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-xs font-medium text-stone-400">Daily pace</p>
                      <p className="font-display mt-1 text-2xl font-semibold tracking-tight tabular-nums">
                        {formatMoney(stats.dailyPace)}{" "}
                        <span className="text-sm font-normal text-stone-400">avg / day</span>
                      </p>
                    </div>
                    <div className="flex rounded-lg bg-stone-100 p-1 dark:bg-stone-800">
                      {RANGES.map((option) => (
                        <button
                          key={option.id}
                          type="button"
                          onClick={() => setRange(option.id)}
                          className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
                            range === option.id
                              ? "bg-white text-stone-900 shadow-sm dark:bg-stone-700 dark:text-stone-100"
                              : "text-stone-500 hover:text-stone-800 dark:text-stone-400 dark:hover:text-stone-200"
                          }`}
                        >
                          {option.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <CategoryBreakdown expenses={ranged} rangeLabel={rangeLabel} />
              <SmartInsights expenses={expenses} budget={budget} />
              <SpendingChart expenses={ranged} range={range} budget={budget} />
              <ExpenseList expenses={expenses} onDelete={deleteExpense} />

              <div className="col-span-12 flex justify-center pt-2">
                <button
                  type="button"
                  onClick={clearAll}
                  className="text-xs font-medium text-stone-400 transition-colors hover:text-red-600 dark:hover:text-red-400"
                >
                  Clear all expenses
                </button>
              </div>
            </>
          )}
        </div>
      </main>

      <button
        type="button"
        onClick={() => setFormOpen(true)}
        className="fixed bottom-6 right-6 z-40 inline-flex items-center gap-2 rounded-full bg-brand px-5 py-3 text-sm font-semibold text-white shadow-lg ring-1 ring-brand/30 transition-transform hover:-translate-y-0.5"
      >
        <Plus className="size-4" /> Quick add expense
      </button>

      <ExpenseForm
        open={formOpen}
        onClose={() => setFormOpen(false)}
        onSubmit={addExpense}
      />
      <BudgetDialog
        open={budgetOpen}
        budget={budget}
        spent={stats.spent}
        onClose={() => setBudgetOpen(false)}
        onSave={updateBudget}
      />
    </div>
  );
}
