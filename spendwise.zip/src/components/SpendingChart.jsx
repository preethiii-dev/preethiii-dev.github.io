import { useEffect, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  formatMoney,
  getCategoryBreakdown,
  getTimeSeries,
  sumOf,
} from "@/lib/finance";

function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg bg-white px-3 py-2 text-xs shadow-lg ring-1 ring-black/5 dark:bg-stone-800 dark:ring-white/10">
      <p className="font-medium text-stone-500 dark:text-stone-400">{label}</p>
      <p className="font-display text-sm font-semibold">
        {formatMoney(payload[0].value)}
      </p>
    </div>
  );
}

const axisProps = {
  tickLine: false,
  axisLine: false,
  tick: { fontSize: 11, fill: "#a8a29e" },
};

export function SpendingChart({ expenses, range, budget }) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const series = getTimeSeries(expenses, range);
  const byCategory = getCategoryBreakdown(expenses);
  const total = sumOf(expenses);
  const used = budget > 0 ? Math.round((total / budget) * 100) : 0;

  return (
    <section
      id="analytics"
      className="col-span-12 grid grid-cols-12 gap-4"
    >
      <div className="col-span-12 rounded-[22px] bg-white p-6 ring-1 ring-black/5 lg:col-span-7 dark:bg-stone-900 dark:ring-white/10">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-sm font-semibold">Spending over time</h2>
          <span className="text-xs text-stone-400">{formatMoney(total)} total</span>
        </div>
        <div className="mt-5 h-56">
          {mounted && series.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={series} margin={{ top: 4, right: 4, left: -18, bottom: 0 }}>
                <defs>
                  <linearGradient id="spendFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#1e7a5b" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#1e7a5b" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="label" {...axisProps} interval="preserveStartEnd" />
                <YAxis {...axisProps} width={48} />
                <Tooltip content={<ChartTooltip />} cursor={{ stroke: "#d6d3d1" }} />
                <Area
                  type="monotone"
                  dataKey="amount"
                  stroke="#1e7a5b"
                  strokeWidth={2}
                  fill="url(#spendFill)"
                  animationDuration={700}
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="grid h-full place-items-center text-sm text-stone-400">
              Nothing to chart in this period yet.
            </div>
          )}
        </div>
      </div>

      <div className="col-span-12 rounded-[22px] bg-white p-6 ring-1 ring-black/5 lg:col-span-5 dark:bg-stone-900 dark:ring-white/10">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-sm font-semibold">Spending by category</h2>
          <span className="text-xs text-stone-400">{used}% of budget</span>
        </div>
        <div className="mt-5 h-56">
          {mounted && byCategory.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byCategory} margin={{ top: 4, right: 4, left: -18, bottom: 0 }}>
                <XAxis dataKey="category" {...axisProps} interval={0} tickFormatter={(v) => v.slice(0, 4)} />
                <YAxis {...axisProps} width={48} />
                <Tooltip content={<ChartTooltip />} cursor={{ fill: "rgba(120,113,108,0.08)" }} />
                <Bar dataKey="amount" radius={[6, 6, 0, 0]} animationDuration={700}>
                  {byCategory.map((item) => (
                    <Cell key={item.category} fill={item.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="grid h-full place-items-center text-sm text-stone-400">
              Nothing to chart in this period yet.
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
