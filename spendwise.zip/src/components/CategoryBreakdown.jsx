import { formatMoney, getCategoryBreakdown, sumOf } from "@/lib/finance";

export function CategoryBreakdown({ expenses, rangeLabel }) {
  const breakdown = getCategoryBreakdown(expenses);
  const total = sumOf(expenses);

  return (
    <section
      id="breakdown"
      className="col-span-12 rounded-[22px] bg-white p-6 ring-1 ring-black/5 lg:col-span-7 dark:bg-stone-900 dark:ring-white/10"
    >
      <div className="flex items-center justify-between">
        <h2 className="font-display text-sm font-semibold">Where is my money going?</h2>
        <span className="text-xs text-stone-400">
          {formatMoney(total)} · {rangeLabel}
        </span>
      </div>

      {breakdown.length === 0 ? (
        <p className="mt-6 text-sm text-stone-400">
          No spending in this period yet.
        </p>
      ) : (
        <div className="mt-5 space-y-4">
          {breakdown.map((item, index) => (
            <div key={item.category}>
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium">{item.category}</span>
                <span className="tabular-nums text-stone-500 dark:text-stone-400">
                  {formatMoney(item.amount)}{" "}
                  <span className="text-stone-400">· {Math.round(item.percent)}%</span>
                </span>
              </div>
              <div className="mt-1.5 h-2 rounded-full bg-stone-100 dark:bg-stone-800">
                <div
                  className="bar h-2 rounded-full"
                  style={{
                    width: `${item.percent}%`,
                    backgroundColor: item.color,
                    animationDelay: `${index * 90}ms`,
                  }}
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
