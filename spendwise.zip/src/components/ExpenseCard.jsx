import { Trash2 } from "lucide-react";
import {
  CATEGORY_CODES,
  CATEGORY_COLORS,
  formatMoney,
  formatShortDate,
} from "@/lib/finance";

export function ExpenseCard({ expense, onDelete }) {
  const color = CATEGORY_COLORS[expense.category] || CATEGORY_COLORS.Other;

  return (
    <div className="group flex animate-fade-in items-center justify-between gap-3 py-3">
      <div className="flex min-w-0 items-center gap-3">
        <span
          className="grid size-9 shrink-0 place-items-center rounded-lg text-xs font-semibold"
          style={{ backgroundColor: `${color}1f`, color }}
        >
          {CATEGORY_CODES[expense.category] || "OT"}
        </span>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">{expense.name}</p>
          <p className="text-xs text-stone-400">
            {expense.category} · {formatShortDate(expense.date)}
          </p>
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-3">
        <span className="text-sm font-medium tabular-nums">
          {formatMoney(expense.amount)}
        </span>
        <button
          type="button"
          onClick={() => onDelete(expense.id)}
          aria-label={`Delete ${expense.name}`}
          className="rounded-md p-1.5 text-stone-300 transition-colors hover:bg-red-50 hover:text-red-600 dark:text-stone-600 dark:hover:bg-red-950/40 dark:hover:text-red-400"
        >
          <Trash2 className="size-4" />
        </button>
      </div>
    </div>
  );
}
