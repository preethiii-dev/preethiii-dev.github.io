import { Sparkles } from "lucide-react";
import { getInsights } from "@/lib/finance";

export function SmartInsights({ expenses, budget }) {
  const insights = getInsights(expenses, budget);

  return (
    <section
      id="insights"
      className="col-span-12 rounded-[22px] bg-white p-6 ring-1 ring-black/5 lg:col-span-5 dark:bg-stone-900 dark:ring-white/10"
    >
      <div className="flex items-center gap-2">
        <span className="grid size-7 place-items-center rounded-lg bg-accent/15 text-accent">
          <Sparkles className="size-4" />
        </span>
        <h2 className="font-display text-sm font-semibold">Smart insights</h2>
      </div>
      <ul className="mt-5 space-y-3.5">
        {insights.map((insight) => (
          <li
            key={insight.text}
            className="flex animate-fade-in gap-3 text-sm leading-relaxed"
          >
            <span
              className={`mt-1.5 size-1.5 shrink-0 rounded-full ${
                insight.tone === "warn" ? "bg-accent" : "bg-brand"
              }`}
            />
            <span>{insight.text}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
